This directory contains the MPEG-1 public source code for the Audio decoder
layer 1, 2 and 3 as per printing of CD 11172-5 in April 1994.

The version number is 4.1.

As you can read in the source files work on these files is still in 
progress and they have not officially been released for public distribution.
Nevertheless we at Fraunhofer Institute have tested the layer 3 part of 
the Decoder and believe that it is reasonably bug free.
So feel free to evaluate the source code but keep in mind, that no 
warranties are associated with this software.

While we believe that this software is reasonably bug free and well behaved,
we are in no way responsible if this software does not work the way you
would expect it to work. No matter if it locks up your computer, garbles
your floppy disks or does any other harmful things to your computer - it
is entirely your problem.
Fraunhofer - IIS and the authors of this software are not liable for 
any infringments or damages of third parties' rights in consequence 
of your use of this software. Fraunhofer - IIS or the authors are in no 
event liable for, respectively do not warrant the trustworthiness, 
quality, industrial exploitability, serviceability of this 
software for the supposed purposeor any other purposes.







