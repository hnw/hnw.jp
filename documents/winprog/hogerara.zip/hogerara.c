#include <windows.h>
#include <stdio.h>
#include <assert.h>
#include "resource.h"

#define BUFFER_SIZE 2048

/* list & tree which represents hierarchy of the windows */
typedef struct _hwndnode {
    struct _hwndnode *next;
    struct _hwndnode *sister;
    struct _hwndnode *child;
    HWND hwnd;
    HWND parent_hwnd;
    int flag; /* -1:dummy 0:toplevelwindow 1:childwindow 2:desktopwindow */
} hwndnode;

/* alloc & set initial value. */
hwndnode *alloc_hwndnode(HWND hwnd, hwndnode *next, int flag)
{
    hwndnode *node;
    node = (hwndnode *)malloc(sizeof(hwndnode));
    node->next = next;
    node->child = NULL;
    node->sister = NULL;
    node->hwnd = hwnd;
    node->parent_hwnd = GetParent(hwnd);
    node->flag = flag;
    return node;
}

void free_hwndnode(hwndnode *node)
{
    free(node);
}

/* returns pointer to the node whose hwnd equals 2nd arg */
hwndnode *getnode(hwndnode *node, HWND hwnd)
{
    while (node) {
        if (hwnd == node->hwnd) {
            return node;
        }
        node = node->next;
    }
    return NULL;
}

BOOL CALLBACK func4child(HWND hwnd, LPARAM lParam)
{
    hwndnode *top;
    top = (hwndnode *)lParam;
    top->next = alloc_hwndnode(hwnd, top->next, 1);
  
    return TRUE;
    
}
BOOL CALLBACK func4toplevel(HWND hwnd, LPARAM lParam)
{
    hwndnode *top, *node;
    top = (hwndnode *)lParam;

    EnumChildWindows(hwnd, func4child, lParam);
    top->next = alloc_hwndnode(hwnd, top->next, 0);

/*    printf("%c\t%08X\t%08X\n",
           IsWindowVisible(hwnd) ? '*' : ' ',
           hwnd, node->parent_hwnd);
*/

    return TRUE;
}

int displaytree_onlistbox(HWND hwnd_listbox, hwndnode *node, int menu_id, int depth)
{
    while (node) {
        char buf[BUFFER_SIZE], buf2[BUFFER_SIZE];
        int ret, index;
        HWND hwnd;

        buf[BUFFER_SIZE-1] = '\0';
        hwnd = node->hwnd;
        ret = GetClassName(hwnd, buf, BUFFER_SIZE);
//        assert(ret != 0);
        if (menu_id == IDM_TITLE) {
            GetWindowText(hwnd, buf, BUFFER_SIZE);
        }
        sprintf(buf2, "%c\t%c\t%c\t%08X\t%08X\t%3d\t%*s %s",
                IsWindowVisible(hwnd) ? '*' : ' ',
                (node->flag == 0) ? 't' : ' ',
                (GetWindowLong(hwnd, GWL_STYLE) & WS_CHILD) ? 'c' : ' ',
                hwnd, node->parent_hwnd,
                strlen(buf), depth*3+2, "+ ", buf);
        index = (WORD)SendMessage(hwnd_listbox, LB_ADDSTRING, 0, (LPARAM)buf2);
        SendMessage(hwnd_listbox, LB_SETITEMDATA, index, (LPARAM)hwnd);
        if (node->child) {
            displaytree_onlistbox(hwnd_listbox, node->child, menu_id, depth+1);
        }
        node = node->sister;
    }
    return 0;
}

/* make tree from the linked-list in top->next */
int make_hwndtree_fromlist(hwndnode *top)
{
    hwndnode *node, *parent;
    node = top->next;
    while (node) {
        parent = getnode(top->next, node->parent_hwnd);
        if (parent) {
            node->sister = parent->child;
            parent->child = node;
        } else {
//            assert(top->hwnd ==  node->parent_hwnd);
            node->sister = top->child;
            top->child = node;
        }
        node = node->next;
    }
    return 0;
}

int make_hwndtree(hwndnode *top)
{
    LPARAM lParam;

    lParam = (LPARAM)top;
    EnumWindows(func4toplevel, lParam);
    /* now we have linked-list pointed by top->next (but no tree) */

    /* add desktopwindow to the list*/
    top->next = alloc_hwndnode(GetDesktopWindow(), top->next, 2);

    make_hwndtree_fromlist(top);
    return 0;
}

int free_hwndtree(hwndnode *node)
{
    hwndnode *prev;
    while (node) {
        prev = node;
        node = node->next;
        free_hwndnode(prev);
    }
    return 0;
}

BOOL FAR PASCAL _export DlgProc(HWND hwnd, UINT message,
                                WPARAM wParam, LPARAM lParam)
{
    HWND hwnd_edit, hwnd_list, hwnd_hoge, hwnd_rara, sel_hwnd;
    HMENU menu;
    static hwndnode *top; /* pointer to dummy node */
    int index, topindex;

    switch (message) {
      case WM_INITDIALOG:
        hwnd_list = GetDlgItem(hwnd, IDC_LIST);
        top = alloc_hwndnode((HWND)0, NULL, -1);

        menu = GetMenu(hwnd);
        CheckMenuItem(menu, IDM_CLASS, MF_CHECKED);
        {
            int tabarray[7] = {8,16,24,60,96,118,200};
            SendMessage(hwnd_list, LB_SETTABSTOPS, 7, (LPARAM)tabarray);
        }

        make_hwndtree(top);
        displaytree_onlistbox(hwnd_list, top->child, 0, 0);

/*        printf("%c\t%08X\t%08X\n",
               IsWindowVisible(GetDesktopWindow()) ? '*' : ' ',
               GetDesktopWindow(), GetParent(GetDesktopWindow()));
*/
        return TRUE;
      case WM_CLOSE:
        EndDialog(hwnd, 0);
        return TRUE;
      case WM_SIZE:
        hwnd_hoge = GetDlgItem(hwnd, IDC_HOGE);
        hwnd_rara = GetDlgItem(hwnd, IDC_RARA);
        hwnd_list = GetDlgItem(hwnd, IDC_LIST);
        hwnd_edit = GetDlgItem(hwnd, IDC_EDIT);
        {
            int x, y;
            x = LOWORD(lParam);
            y = HIWORD(lParam);
            MoveWindow(hwnd_hoge, x/2-14-70, y-32, 70, 21, TRUE);
            MoveWindow(hwnd_rara, x/2+14,    y-32, 70, 21, TRUE);
            MoveWindow(hwnd_edit, 2, 0,  x-4, 72, TRUE);
            MoveWindow(hwnd_list, 2, 75, x-4, y-120, TRUE);
        }
//        printf("%d %d\n", LOWORD(lParam), HIWORD(lParam));
//        (0, 0) - (568, 346) 284
//        (200, 312) - (270, 333)
//        (298, 312) - (368, 333)
//        (6, 42) - (563, 117)
//        (6, 132) - (563, 292)
        return TRUE;
      case WM_COMMAND:
        if (LOWORD(lParam) == 0) {
            int menu_id = wParam;
            switch (menu_id) {
              case IDM_EXIT:
                PostQuitMessage(0);
                break;
              case IDM_CLASS:
              case IDM_TITLE:
                hwnd_list = GetDlgItem(hwnd, IDC_LIST);
                topindex = SendMessage(hwnd_list, LB_GETTOPINDEX, 0, 0);
                index = (WORD)SendMessage(hwnd_list, LB_GETCURSEL, 0, 0L);
                
                free_hwndtree(top->next);
                SendMessage(hwnd_list, LB_RESETCONTENT, 0, 0L);
                
                top->next = top->child = NULL;
                top->hwnd = (HWND)0;

                make_hwndtree(top);
                SendMessage(hwnd_list, WM_SETREDRAW, FALSE, 0L);
                displaytree_onlistbox(hwnd_list, top->child, menu_id, 0);
                SendMessage(hwnd_list, LB_SETTOPINDEX, topindex, 0);
                if (index != LB_ERR) {
                    SendMessage(hwnd_list, LB_SETCURSEL, index, 0);
                }
                SendMessage(hwnd_list, WM_SETREDRAW, TRUE, 0L);
                
                menu = GetMenu(hwnd);
                CheckMenuItem(menu, IDM_TITLE, MF_UNCHECKED);
                CheckMenuItem(menu, IDM_CLASS, MF_UNCHECKED);
                CheckMenuItem(menu, menu_id, MF_CHECKED);
                break;
              case IDM_ABOUT:
                hwnd_edit  = GetDlgItem(hwnd, IDC_EDIT);
                SendMessage(hwnd_edit, WM_SETTEXT, 0,
                            (LPARAM)"hogerara ver 0.000411.0947  (c) ginza5432");
                break;
            }
        } else {
            switch (LOWORD(wParam)) {
              case IDC_HOGE:
                hwnd_edit = GetDlgItem(hwnd, IDC_EDIT);
                SendMessage(hwnd_edit, WM_SETTEXT, 0, (LPARAM)"hoge");
                return TRUE;
              case IDC_RARA:
                hwnd_edit = GetDlgItem(hwnd, IDC_EDIT);
                SendMessage(hwnd_edit, WM_SETTEXT, 0, (LPARAM)"rara");
                return TRUE;
              case IDC_LIST:
                switch (HIWORD(wParam)) {
                  case LBN_SELCHANGE:
                    hwnd_list = GetDlgItem(hwnd, IDC_LIST);
                    hwnd_edit = GetDlgItem(hwnd, IDC_EDIT);
                    index = (WORD)SendMessage(hwnd_list, LB_GETCURSEL, 0, 0L);
                    sel_hwnd = (HWND)SendMessage(hwnd_list, LB_GETITEMDATA, index, 0L);
                    {
                        char str[64];
                        RECT rect;
                        HDC hdc;
                        int rop2;
                        int width;
                        int height;
                        HANDLE hpen;
                        HANDLE hbr;

                        GetWindowRect(sel_hwnd, &rect);
/*
                        hdc = GetWindowDC(sel_hwnd);
                        width = rect.right-rect.left;
                        height = rect.bottom-rect.top;
                        rop2 = SetROP2(hdc, R2_XORPEN);
                        if (rop2 && height && width)
                        {
                            hpen = SelectObject(hdc, GetStockObject(WHITE_PEN));
                            hbr  = SelectObject(hdc, GetStockObject(NULL_BRUSH));
                            Rectangle(hdc, 0, 0, width    , height    );
                            Rectangle(hdc, 1, 1, width - 1, height - 1);
                            Rectangle(hdc, 2, 2, width - 2, height - 2);
                            SelectObject(hdc, hpen);
                            SelectObject(hdc, hbr);
                            // no need to DeleteObject StockObject
                            SetROP2(hdc, rop2);
                        }
                        ReleaseDC(sel_hwnd, hdc);
                        
*/
                        sprintf(str, "(%d, %d) - (%d, %d)",
                                rect.left, rect.top, rect.right, rect.bottom);
                        SendMessage(hwnd_edit, WM_SETTEXT, 0, (LPARAM)str);
                    }



/*
                    {
                        int j;
                        char *p;
                        index = (WORD)SendMessage(hwnd_list, LB_GETCURSEL, 0, 0L);
                        j = (WORD)SendMessage(hwnd_list, LB_GETTEXTLEN, index, 0L);
                        p = malloc(sizeof(char)*(j+1));
                        SendMessage(hwnd_list, LB_GETTEXT, index, (LONG)(LPSTR) p);
                        SendMessage(hwnd_edit, WM_SETTEXT, 0, (LPARAM)p);
                        free(p);
                    }
*/
                }
                return TRUE;
            }
        }
        break;
    }
    return FALSE;
}


int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpszCmdParam, int nCmdShow)
{
    return DialogBox(hInstance, "hogerara" , 0, DlgProc);
}


/*
SetWindowsHookEx ���݂�ׂ��B
*/