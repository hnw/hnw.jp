#include <windows.h>

#define IDC_HOGE 64
#define IDC_RARA 65
#define IDC_EDIT 66
#define IDC_LIST 67

#define IDM_EXIT 128
#define IDM_CLASS 129
#define IDM_TITLE 130
#define IDM_ABOUT 131
